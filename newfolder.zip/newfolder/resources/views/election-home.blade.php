@extends('layouts.election-template')

@section('content')


<!-- banner -->
<div class="banner">
		<div class="container text-center">

<div 
class="col-md-offset-4"

style="
width:300px;  
margin-top: 20%; 
padding-top: 40px;
 padding-bottom: 40px;
  padding-right: 20px; 
  padding-left: 20px; 
  background-color: black; 
  border-radius: 10px;
  background:rgba(0, 0, 0, 0.6);
  ">
  <div>
              <a   href="/login/facebook" 
              class="btn  btn-primary btn-facebook btn-flat"
             
              ><i class="fa fa-facebook"></i> Sign in using
  Facebook</a>

  </div>
  </div>
                            
                            </div>              
                
				
			</div>

            


@endsection